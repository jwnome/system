# Newaita-reborn
Newaita remaster icon theme

# Newaita-reborn
Newaita remaster icon theme
<p align="center">
  <img src="https://raw.githubusercontent.com/cbrnix/Newaita-reborn/master/cover.png" alt="preview"/>
</p>
